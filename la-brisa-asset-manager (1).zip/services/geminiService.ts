
import { GoogleGenAI, Type } from "@google/genai";
import { Category, Condition } from "../types";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getInventoryChecklist = async (propertyType: string, style: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Generate a comprehensive inventory checklist for a short-term rental property of type "${propertyType}" with a "${style}" style. 
    Include essential items for Furnishings, Kitchen Appliances, and Linens. 
    Return the result in a structured JSON format.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            category: { type: Type.STRING, enum: Object.values(Category) },
            quantity: { type: Type.NUMBER },
            notes: { type: Type.STRING }
          },
          required: ["name", "category", "quantity"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (e) {
    console.error("Failed to parse AI response", e);
    return [];
  }
};

export const analyzePropertyStatus = async (propertyName: string, items: any[]) => {
  const itemSummary = items.map(i => `${i.name} (${i.quantity} units, status: ${i.condition})`).join(", ");
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `You are an expert hospitality consultant. Analyze the following inventory for the property "${propertyName}": ${itemSummary}. 
    Identify missing essentials or items in bad condition that need immediate attention for a 5-star Airbnb guest experience. 
    Provide 3-5 concise bullet points.`,
  });

  return response.text;
};
