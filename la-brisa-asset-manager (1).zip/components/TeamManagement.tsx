
import React, { useState } from 'react';
import { User, Role } from '../types';

interface Props {
  users: User[];
  onInvite: (user: Omit<User, 'id' | 'status'>) => void;
  onDelete: (id: string) => void;
  onUpdateRole: (id: string, role: Role) => void;
}

export const TeamManagement: React.FC<Props> = ({ users, onInvite, onDelete, onUpdateRole }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({ firstName: '', lastName: '', email: '', role: Role.AUDITOR });
  const [showInviteSuccess, setShowInviteSuccess] = useState(false);

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    onInvite(formData);
    setFormData({ firstName: '', lastName: '', email: '', role: Role.AUDITOR });
    setIsModalOpen(false);
    setShowInviteSuccess(true);
    setTimeout(() => setShowInviteSuccess(false), 3000);
  };

  const getRoleBadge = (role: Role) => {
    switch (role) {
      case Role.ADMIN: return 'bg-purple-100 text-purple-700';
      case Role.MANAGER: return 'bg-blue-100 text-blue-700';
      case Role.AUDITOR: return 'bg-amber-100 text-amber-700';
      case Role.VIEWER: return 'bg-slate-100 text-slate-700';
    }
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Team Management</h2>
          <p className="text-slate-500 mt-1">Manage employee access and authority restrictions.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-labriza text-white px-5 py-2.5 rounded-lg font-semibold shadow-lg shadow-blue-900/20 hover:opacity-90 transition-all flex items-center"
        >
          <svg className="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg>
          Invite Team Member
        </button>
      </header>

      {showInviteSuccess && (
        <div className="bg-emerald-50 border border-emerald-100 text-emerald-700 px-4 py-3 rounded-lg flex items-center animate-fade-in-down">
          <svg className="w-5 h-5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
          Invitation email sent successfully! The user can now create their password.
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-200 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            <tr>
              <th className="px-6 py-4">Employee Name</th>
              <th className="px-6 py-4">Email Address</th>
              <th className="px-6 py-4">Authority Level</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map(user => (
              <tr key={user.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4">
                  <div className="font-semibold text-slate-900">{user.firstName} {user.lastName}</div>
                </td>
                <td className="px-6 py-4 text-slate-500 text-sm">{user.email}</td>
                <td className="px-6 py-4">
                  <select 
                    value={user.role}
                    onChange={(e) => onUpdateRole(user.id, e.target.value as Role)}
                    className={`text-xs font-bold px-3 py-1 rounded-full border-none focus:ring-2 focus:ring-labriza outline-none cursor-pointer ${getRoleBadge(user.role)}`}
                  >
                    {Object.values(Role).map(r => <option key={r} value={r}>{r}</option>)}
                  </select>
                </td>
                <td className="px-6 py-4">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-tighter ${user.status === 'Active' ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400 bg-slate-50'}`}>
                    {user.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  {user.role !== Role.ADMIN && (
                    <button 
                      onClick={() => onDelete(user.id)}
                      className="text-slate-300 hover:text-rose-500 transition-colors"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-xl font-bold text-slate-900">Invite Team Member</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
            </div>
            <form className="p-6 space-y-4" onSubmit={handleInvite}>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">First Name</label>
                  <input required type="text" value={formData.firstName} onChange={e => setFormData({...formData, firstName: e.target.value})} className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-labriza outline-none" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Last Name</label>
                  <input required type="text" value={formData.lastName} onChange={e => setFormData({...formData, lastName: e.target.value})} className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-labriza outline-none" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Corporate Email</label>
                <input required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-labriza outline-none" placeholder="name@labriza.com" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Authority Level</label>
                <select value={formData.role} onChange={e => setFormData({...formData, role: e.target.value as Role})} className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-labriza outline-none">
                  {Object.values(Role).map(r => <option key={r} value={r}>{r}</option>)}
                </select>
                <p className="text-[10px] text-slate-400 mt-1 italic">
                  {formData.role === Role.ADMIN && "Full unrestricted access to all assets and team management."}
                  {formData.role === Role.MANAGER && "Can add/edit assets and stays. No deletions allowed."}
                  {formData.role === Role.AUDITOR && "Can only perform inventory checks and update conditions/remarks."}
                  {formData.role === Role.VIEWER && "Read-only access to all properties and reports."}
                </p>
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-slate-500 font-semibold hover:bg-slate-50 rounded-lg">Cancel</button>
                <button type="submit" className="bg-labriza text-white px-6 py-2 rounded-lg font-bold shadow-lg shadow-blue-900/20">Send Invite</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
