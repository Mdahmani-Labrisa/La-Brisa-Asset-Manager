
import React from 'react';
import { InventoryItem, Condition, Category, Role } from '../types';

interface Props {
  items: InventoryItem[];
  onUpdate: (id: string, updates: Partial<InventoryItem>) => void;
  onDelete: (id: string) => void;
  onClearSection?: (roomName: string) => void;
  userRole: Role;
}

export const InventoryTable: React.FC<Props> = ({ items, onUpdate, onDelete, onClearSection, userRole }) => {
  const isReadOnly = userRole === Role.VIEWER;
  const canEditStructures = userRole === Role.ADMIN || userRole === Role.MANAGER;
  
  const getConditionColor = (c: Condition) => {
    switch (c) {
      case Condition.EXCELLENT: return 'bg-emerald-100 text-emerald-700';
      case Condition.GOOD: return 'bg-blue-100 text-blue-700';
      case Condition.WORN: return 'bg-amber-100 text-amber-700';
      case Condition.DAMAGED: return 'bg-rose-100 text-rose-700';
      case Condition.MISSING: return 'bg-slate-200 text-slate-700';
    }
  };

  const groupedItems = items.reduce((acc, item) => {
    const room = item.room || 'General';
    if (!acc[room]) acc[room] = [];
    acc[room].push(item);
    return acc;
  }, {} as Record<string, InventoryItem[]>);

  const rooms = Object.keys(groupedItems).sort();

  return (
    <div className="space-y-8">
      {rooms.map((room) => (
        <div key={room} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider flex items-center">
              <svg className="w-4 h-4 mr-2 text-labriza" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
              </svg>
              {room}
            </h3>
            <div className="flex items-center space-x-4">
              <span className="text-xs font-medium text-slate-400">{groupedItems[room].length} Items</span>
              {onClearSection && canEditStructures && !isReadOnly && (
                <button 
                  onClick={() => {
                    if(confirm(`Are you sure you want to remove the entire "${room}" section?`)) {
                      onClearSection(room);
                    }
                  }}
                  className="text-[10px] font-bold text-rose-400 hover:text-rose-600 uppercase tracking-tighter transition-colors"
                >
                  Remove Section
                </button>
              )}
            </div>
          </div>
          <table className="w-full text-left table-fixed">
            <thead className="bg-slate-50/50 border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              <tr>
                <th className="px-6 py-3 w-1/4">Item Name</th>
                <th className="px-6 py-3 w-1/6">Category</th>
                <th className="px-6 py-3 w-32">Qty</th>
                <th className="px-6 py-3 w-40">Condition</th>
                <th className="px-6 py-3">Remarks / Details</th>
                <th className="px-6 py-3 w-20 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {groupedItems[room].map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <input 
                      type="text"
                      disabled={!canEditStructures || isReadOnly}
                      value={item.name}
                      onChange={(e) => onUpdate(item.id, { name: e.target.value })}
                      className={`font-medium text-slate-900 bg-transparent border-none rounded px-1 -ml-1 w-full outline-none truncate ${(!canEditStructures || isReadOnly) ? 'cursor-default' : 'focus:ring-1 focus:ring-labriza'}`}
                    />
                  </td>
                  <td className="px-6 py-4">
                    <select 
                      disabled={!canEditStructures || isReadOnly}
                      value={item.category}
                      onChange={(e) => onUpdate(item.id, { category: e.target.value as Category })}
                      className={`text-xs text-slate-600 bg-transparent border-none p-0 ${(!canEditStructures || isReadOnly) ? 'cursor-default appearance-none' : 'focus:ring-0 cursor-pointer'}`}
                    >
                      {Object.values(Category).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-2">
                       {canEditStructures && !isReadOnly && (
                         <button 
                          onClick={() => onUpdate(item.id, { quantity: Math.max(0, item.quantity - 1) })}
                          className="w-6 h-6 rounded border border-slate-200 flex items-center justify-center hover:bg-slate-100 text-slate-500"
                         >-</button>
                       )}
                       <span className="text-sm font-semibold w-6 text-center text-slate-700">{item.quantity}</span>
                       {canEditStructures && !isReadOnly && (
                         <button 
                          onClick={() => onUpdate(item.id, { quantity: item.quantity + 1 })}
                          className="w-6 h-6 rounded border border-slate-200 flex items-center justify-center hover:bg-slate-100 text-slate-500"
                         >+</button>
                       )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <select 
                      disabled={isReadOnly}
                      value={item.condition}
                      onChange={(e) => onUpdate(item.id, { condition: e.target.value as Condition })}
                      className={`text-[10px] font-bold px-2 py-1 rounded-full border-none uppercase tracking-tighter w-full text-center ${isReadOnly ? 'cursor-default' : 'focus:ring-2 focus:ring-labriza cursor-pointer'} ${getConditionColor(item.condition)}`}
                    >
                      {Object.values(Condition).map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-6 py-4">
                    <input 
                      type="text"
                      disabled={isReadOnly}
                      placeholder={isReadOnly ? "" : "Add remarks..."}
                      value={item.notes || ''}
                      onChange={(e) => onUpdate(item.id, { notes: e.target.value })}
                      className={`text-xs text-slate-500 bg-transparent border-none rounded px-2 py-1 w-full outline-none placeholder:text-slate-300 italic ${isReadOnly ? 'cursor-default' : 'focus:ring-1 focus:ring-labriza'}`}
                    />
                  </td>
                  <td className="px-6 py-4 text-right">
                    {canEditStructures && !isReadOnly && (
                      <button 
                        onClick={() => onDelete(item.id)}
                        className="text-slate-300 hover:text-rose-500 transition-colors"
                      >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
};
